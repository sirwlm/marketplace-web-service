<?php
/**
                                                                             
                                                                             
                                                                             
$$\   $$\     $$$$$$$$\  $$$$$$\  $$\      $$\ $$$$$$$\  $$$$$$$$\ $$$$$$$\  
$$ |  $$ |    \__$$  __|$$  __$$\ $$$\    $$$ |$$  __$$\ $$  _____|$$  __$$\ 
\$$\ $$  |       $$ |   $$ /  $$ |$$$$\  $$$$ |$$ |  $$ |$$ |      $$ |  $$ |
 \$$$$  /$$$$$$\ $$ |   $$$$$$$$ |$$\$$\$$ $$ |$$$$$$$  |$$$$$\    $$$$$$$  |
 $$  $$< \______|$$ |   $$  __$$ |$$ \$$$  $$ |$$  ____/ $$  __|   $$  __$$< 
$$  /\$$\        $$ |   $$ |  $$ |$$ |\$  /$$ |$$ |      $$ |      $$ |  $$ |
$$ /  $$ |       $$ |   $$ |  $$ |$$ | \_/ $$ |$$ |      $$$$$$$$\ $$ |  $$ |
\__|  \__|       \__|   \__|  \__|\__|     \__|\__|      \________|\__|  \__|
                                                                             
                                                                             
                                                                             
**/
// signin
$ERROR = "Some of your info isn't correct. Please try again.";
$Email ='Email';
$Password ='Password';
$dok ='Log In';
$req1 = 'Required';
$req2 = 'Required';
$forgot ='Having trouble logging in?';
$sign = 'Sign Up';
$checking = 'Checking your info…';
$priva ='Privacy';
$ri8 = 'All rights reserved';
$legal = 'Legal';
// end signin
?>