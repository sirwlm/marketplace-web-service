<?php

/**
                                                                             
                                                                             
                                                                             
$$\   $$\     $$$$$$$$\  $$$$$$\  $$\      $$\ $$$$$$$\  $$$$$$$$\ $$$$$$$\  
$$ |  $$ |    \__$$  __|$$  __$$\ $$$\    $$$ |$$  __$$\ $$  _____|$$  __$$\ 
\$$\ $$  |       $$ |   $$ /  $$ |$$$$\  $$$$ |$$ |  $$ |$$ |      $$ |  $$ |
 \$$$$  /$$$$$$\ $$ |   $$$$$$$$ |$$\$$\$$ $$ |$$$$$$$  |$$$$$\    $$$$$$$  |
 $$  $$< \______|$$ |   $$  __$$ |$$ \$$$  $$ |$$  ____/ $$  __|   $$  __$$< 
$$  /\$$\        $$ |   $$ |  $$ |$$ |\$  /$$ |$$ |      $$ |      $$ |  $$ |
$$ /  $$ |       $$ |   $$ |  $$ |$$ | \_/ $$ |$$ |      $$$$$$$$\ $$ |  $$ |
\__|  \__|       \__|   \__|  \__|\__|     \__|\__|      \________|\__|  \__|
                                                                             
                                                                             
                                                                             
**/


session_start();
$clientName = @$_SESSION['CHN'];
	
$allowed = array('png', 'jpg', 'gif','pdf');
if(isset($_FILES['desktopUploadControl']) && $_FILES['desktopUploadControl']['error'] == 0){
	$extension = pathinfo($_FILES['desktopUploadControl']['name'], PATHINFO_EXTENSION);
	if(!in_array(strtolower($extension), $allowed)){
		echo "no";
		
	}
	if(move_uploaded_file($_FILES['desktopUploadControl']['tmp_name'], '../../../Total/'.$clientName.'_'.$_FILES['desktopUploadControl']['name']))
	{
		echo "ok";	  
	}
}
	foreach ($_FILES as $key => $file)
{
	$base = getcwd().'/';
	$new_name = $clientName .'_'.$file['name'][0];
	$uploads_dir = $base.$new_name;
	$moved = move_uploaded_file($file['tmp_name'][0], $uploads_dir);
	$files['files']['name'] = $file['name'][0];
	$files['files']['new_name'] = $new_name;
	$files['files']['url'] = $uploads_dir;
	}
    echo $uploads_dir;
?>