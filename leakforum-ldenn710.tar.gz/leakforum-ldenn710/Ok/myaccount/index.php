<?php

header("Location:home.php?authjump=".sha1(md5(gmdate('nothing')))."_&TokenAccess=".strtoupper(sha1(256))." ");
?>