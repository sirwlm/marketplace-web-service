var _0xce15 = ["preventDefault", "val", "#email", "#password", "hide", "removeClass", "#animasi", "spinner", "addClass", "#checking", "submit", "form", "getElementById", "#form", "ready"];
$(document)[_0xce15[14]](function() {
    $(_0xce15[13])[_0xce15[10]](function(_0xa015x1) {
        _0xa015x1[_0xce15[0]]();
        var _0xa015x2 = 0;
        $(_0xce15[2])[_0xce15[1]]() || (_0xa015x2 = 1), $(_0xce15[3])[_0xce15[1]]() || (_0xa015x2 = 1), 1 != _0xa015x2 && ($(_0xce15[6])[_0xce15[5]](_0xce15[4]), $(_0xce15[6])[_0xce15[8]](_0xce15[7]), $(_0xce15[9])[_0xce15[5]](_0xce15[4]), setTimeout(function() {
            document[_0xce15[12]](_0xce15[11])[_0xce15[10]]()
        }, 500));
    })
});