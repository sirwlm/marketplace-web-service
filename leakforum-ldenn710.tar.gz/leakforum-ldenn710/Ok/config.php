﻿<?php


$yours = "itsabird@tuta.io"; 

?>
